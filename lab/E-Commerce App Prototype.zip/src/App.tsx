import { useState } from "react";

type IconName =
  | "arrow"
  | "bag"
  | "check"
  | "chevron"
  | "heart"
  | "home"
  | "minus"
  | "plus"
  | "search"
  | "user";

type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  color: string;
};

const products: Product[] = [
  {
    id: 1,
    name: "Orbit Runner",
    category: "Everyday sneaker",
    price: 128,
    image:
      "https://images.unsplash.com/photo-1700178310305-0e05d7930f9f?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900",
    color: "Oat / Ink",
  },
  {
    id: 2,
    name: "Cloud Serum",
    category: "Daily hydration",
    price: 42,
    image:
      "https://images.unsplash.com/photo-1616750819456-5cdee9b85d22?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900",
    color: "50 ml",
  },
  {
    id: 3,
    name: "Daylight Blazer",
    category: "Relaxed tailoring",
    price: 184,
    image:
      "https://images.unsplash.com/photo-1613915617430-8ab0fd7c6baf?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900",
    color: "Sandstone",
  },
  {
    id: 4,
    name: "Essential Set",
    category: "Clean skincare",
    price: 68,
    image:
      "https://images.unsplash.com/photo-1718490953028-021d352b14fd?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900",
    color: "5 piece set",
  },
];

function Icon({ name, filled = false }: { name: IconName; filled?: boolean }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9M9 20v-7h6v7" /></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
    bag: <><path d="M5 8h14l-1 13H6L5 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4.5 21a7.5 7.5 0 0 1 15 0" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    arrow: <><path d="m15 18-6-6 6-6" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    minus: <path d="M5 12h14" />,
    check: <path d="m5 12 4 4L19 6" />,
  };

  return (
    <svg
      aria-hidden="true"
      className="icon"
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function ProductCard({
  product,
  liked,
  onLike,
  onOpen,
}: {
  product: Product;
  liked: boolean;
  onLike: () => void;
  onOpen: () => void;
}) {
  return (
    <article className="product-card">
      <div className="product-image-wrap" onClick={onOpen} role="button" tabIndex={0}>
        <img src={product.image} alt={product.name} className="product-image" />
        <button
          className={`heart-button ${liked ? "liked" : ""}`}
          onClick={(event) => {
            event.stopPropagation();
            onLike();
          }}
          aria-label={liked ? "Remove from favorites" : "Add to favorites"}
        >
          <Icon name="heart" filled={liked} />
        </button>
      </div>
      <button className="product-copy" onClick={onOpen}>
        <span className="product-name">{product.name}</span>
        <span className="product-meta">{product.category}</span>
        <span className="product-price">${product.price}</span>
      </button>
    </article>
  );
}

function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon: IconName;
  title: string;
  body: string;
  action: () => void;
}) {
  return (
    <section className="empty-state">
      <div className="empty-icon"><Icon name={icon} /></div>
      <p className="eyebrow">YOUR SPACE</p>
      <p className="empty-title">{title}</p>
      <p className="empty-body">{body}</p>
      <button className="primary-button narrow" onClick={action}>Explore the edit</button>
    </section>
  );
}

export default function App() {
  const [mode, setMode] = useState<"curated" | "all">("curated");
  const [activeTab, setActiveTab] = useState("home");
  const [selected, setSelected] = useState<Product | null>(null);
  const [liked, setLiked] = useState<number[]>([2]);
  const [cartCount, setCartCount] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const toggleLike = (id: number) => {
    setLiked((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  };

  const addToBag = () => {
    setCartCount((current) => current + quantity);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1800);
  };

  const openHome = () => {
    setActiveTab("home");
    setSelected(null);
  };

  return (
    <main className="app-canvas">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <section className="prototype-note">
        <span className="note-dot" />
        <span>Interactive stakeholder prototype</span>
        <strong>Mobile commerce • Concept 01</strong>
      </section>

      <div className="phone">
        <div className="status-bar">
          <span>9:41</span>
          <span className="status-icons">● ◒ ▰</span>
        </div>

        <div className="screen">
          {selected ? (
            <div className="detail-page">
              <div className="detail-visual">
                <img src={selected.image} alt={selected.name} />
                <button className="floating back" onClick={() => setSelected(null)} aria-label="Go back">
                  <Icon name="arrow" />
                </button>
                <button
                  className={`floating favorite ${liked.includes(selected.id) ? "liked" : ""}`}
                  onClick={() => toggleLike(selected.id)}
                  aria-label="Favorite product"
                >
                  <Icon name="heart" filled={liked.includes(selected.id)} />
                </button>
                <span className="image-count">1 / 4</span>
              </div>
              <div className="detail-content">
                <div className="detail-heading">
                  <div>
                    <p className="eyebrow">NEW SEASON</p>
                    <p className="detail-title">{selected.name}</p>
                  </div>
                  <p className="detail-price">${selected.price}</p>
                </div>
                <div className="rating-row">
                  <span className="stars">★★★★★</span>
                  <span>4.9 · 128 reviews</span>
                </div>
                <div className="option-row">
                  <div>
                    <span className="option-label">COLOR</span>
                    <strong>{selected.color}</strong>
                  </div>
                  <div className="swatches"><span /><span /><span /></div>
                </div>
                <div className="quantity-row">
                  <span className="option-label">QUANTITY</span>
                  <div className="stepper">
                    <button onClick={() => setQuantity(Math.max(1, quantity - 1))}><Icon name="minus" /></button>
                    <span>{quantity}</span>
                    <button onClick={() => setQuantity(quantity + 1)}><Icon name="plus" /></button>
                  </div>
                </div>
                <p className="description">
                  Designed for repeat wear, with thoughtful materials and an easy,
                  considered silhouette.
                </p>
              </div>
              <div className="detail-footer">
                <div>
                  <span>Total</span>
                  <strong>${selected.price * quantity}</strong>
                </div>
                <button className={`primary-button ${added ? "success" : ""}`} onClick={addToBag}>
                  {added ? <><Icon name="check" /> Added to bag</> : "Add to bag"}
                </button>
              </div>
            </div>
          ) : (
            <>
              {activeTab === "home" && (
                <div className="home-page">
                  <header className="topbar">
                    <button className="brand" onClick={openHome}>morrow<span>.</span></button>
                    <div className="top-actions">
                      <button aria-label="Search"><Icon name="search" /></button>
                      <button className="bag-action" aria-label="Shopping bag" onClick={() => setActiveTab("bag")}>
                        <Icon name="bag" />
                        {cartCount > 0 && <span>{cartCount}</span>}
                      </button>
                    </div>
                  </header>

                  <div className="view-switch" aria-label="Choose shopping view">
                    <button className={mode === "curated" ? "active" : ""} onClick={() => setMode("curated")}>
                      Curated
                    </button>
                    <button className={mode === "all" ? "active" : ""} onClick={() => setMode("all")}>
                      Shop all
                    </button>
                  </div>

                  {mode === "curated" ? (
                    <>
                      <section className="hero">
                        <img
                          src="https://images.unsplash.com/photo-1659522761084-79196b64abe4?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1000"
                          alt="Woman wearing a flowing white dress"
                        />
                        <div className="hero-gradient" />
                        <div className="hero-copy">
                          <p>THE SUMMER EDIT</p>
                          <h1>Ease, in every detail.</h1>
                          <button onClick={() => setMode("all")}>Explore the collection <Icon name="chevron" /></button>
                        </div>
                      </section>

                      <section className="section-block">
                        <div className="section-heading">
                          <div>
                            <p className="eyebrow">JUST IN</p>
                            <h2>Fresh finds</h2>
                          </div>
                          <button onClick={() => setMode("all")}>View all</button>
                        </div>
                        <div className="product-scroll">
                          {products.slice(0, 3).map((product) => (
                            <ProductCard
                              key={product.id}
                              product={product}
                              liked={liked.includes(product.id)}
                              onLike={() => toggleLike(product.id)}
                              onOpen={() => setSelected(product)}
                            />
                          ))}
                        </div>
                      </section>

                      <section className="value-card">
                        <span className="value-number">01</span>
                        <div>
                          <p className="eyebrow">OUR PROMISE</p>
                          <h2>Fewer, better things.</h2>
                          <p>Considered pieces from makers we trust, selected to last beyond the season.</p>
                        </div>
                      </section>
                    </>
                  ) : (
                    <section className="catalog">
                      <div className="catalog-title">
                        <div>
                          <p className="eyebrow">THE COLLECTION</p>
                          <h1>Find your next favorite.</h1>
                        </div>
                        <span>24 pieces</span>
                      </div>
                      <div className="chips">
                        {["All", "Wear", "Beauty", "Home"].map((chip, index) => (
                          <button key={chip} className={index === 0 ? "active" : ""}>{chip}</button>
                        ))}
                      </div>
                      <div className="product-grid">
                        {products.map((product) => (
                          <ProductCard
                            key={product.id}
                            product={product}
                            liked={liked.includes(product.id)}
                            onLike={() => toggleLike(product.id)}
                            onOpen={() => setSelected(product)}
                          />
                        ))}
                      </div>
                    </section>
                  )}
                </div>
              )}

              {activeTab === "saved" && (
                liked.length ? (
                  <section className="library-page">
                    <p className="eyebrow">YOUR EDIT</p>
                    <h1>Saved for later</h1>
                    <p className="page-subtitle">{liked.length} piece{liked.length > 1 ? "s" : ""} caught your eye.</p>
                    <div className="product-grid">
                      {products.filter((product) => liked.includes(product.id)).map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          liked
                          onLike={() => toggleLike(product.id)}
                          onOpen={() => setSelected(product)}
                        />
                      ))}
                    </div>
                  </section>
                ) : <EmptyState icon="heart" title="Nothing saved yet" body="Tap the heart on pieces you want to revisit." action={openHome} />
              )}

              {activeTab === "bag" && (
                <EmptyState
                  icon="bag"
                  title={cartCount ? `${cartCount} item${cartCount > 1 ? "s" : ""} in your bag` : "Your bag is ready"}
                  body={cartCount ? "Your selection is saved. Checkout is next." : "Add something considered to make it yours."}
                  action={openHome}
                />
              )}

              {activeTab === "profile" && (
                <EmptyState icon="user" title="Make it personal" body="Sign in to track orders, save sizes, and shape your edit." action={openHome} />
              )}

              <nav className="bottom-nav">
                {[
                  { id: "home", label: "Discover", icon: "home" },
                  { id: "saved", label: "Saved", icon: "heart" },
                  { id: "bag", label: "Bag", icon: "bag" },
                  { id: "profile", label: "You", icon: "user" },
                ].map((item) => (
                  <button
                    key={item.id}
                    className={activeTab === item.id ? "active" : ""}
                    onClick={() => setActiveTab(item.id)}
                  >
                    <span className="nav-icon">
                      <Icon name={item.icon as IconName} filled={activeTab === item.id && item.id === "heart"} />
                      {item.id === "bag" && cartCount > 0 && <i>{cartCount}</i>}
                    </span>
                    <span>{item.label}</span>
                  </button>
                ))}
              </nav>
            </>
          )}
        </div>
        <div className="home-indicator" />
      </div>
    </main>
  );
}
