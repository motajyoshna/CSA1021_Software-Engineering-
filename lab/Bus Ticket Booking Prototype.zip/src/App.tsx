import { useState, type ReactNode } from "react";

type IconName =
  | "arrow"
  | "bus"
  | "calendar"
  | "check"
  | "chevron"
  | "clock"
  | "headset"
  | "location"
  | "menu"
  | "search"
  | "shield"
  | "swap"
  | "ticket"
  | "users"
  | "wifi";

function Icon({ name, className = "size-5" }: { name: IconName; className?: string }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></>,
    bus: <><path d="M6 17h12" /><path d="M6 14h12" /><path d="M8 20h0" /><path d="M16 20h0" /><rect x="5" y="3" width="14" height="17" rx="3" /><path d="M8 3v3h8V3" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    headset: <><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><path d="M18 19h-2v-6h4v4a2 2 0 0 1-2 2ZM6 19H4a2 2 0 0 1-2-2v-4h4v6Z" /></>,
    location: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    shield: <><path d="M12 22s8-3 8-10V5l-8-3-8 3v7c0 7 8 10 8 10Z" /><path d="m9 12 2 2 4-5" /></>,
    swap: <><path d="m7 7 3-3 3 3" /><path d="M10 4v16" /><path d="m17 17-3 3-3-3" /></>,
    ticket: <><path d="M2 9a3 3 0 0 0 0 6v3h20v-3a3 3 0 0 0 0-6V6H2v3Z" /><path d="M13 8v2M13 14v2" /></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
    wifi: <><path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0" /><circle cx="12" cy="20" r=".5" fill="currentColor" /></>,
  };

  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

const routes = [
  { from: "New York", to: "Boston", duration: "4h 20m", price: 29, color: "bg-[#fff4e8]", accent: "text-[#eb6c2d]" },
  { from: "Chicago", to: "Detroit", duration: "5h 15m", price: 34, color: "bg-[#eaf6f3]", accent: "text-[#167a68]" },
  { from: "Los Angeles", to: "Las Vegas", duration: "5h 45m", price: 38, color: "bg-[#f0effb]", accent: "text-[#6959c9]" },
];

function Field({
  icon,
  label,
  value,
  children,
}: {
  icon: IconName;
  label: string;
  value?: string;
  children?: ReactNode;
}) {
  return (
    <div className="group flex min-w-0 flex-1 items-center gap-3 rounded-2xl px-4 py-3 transition hover:bg-[#f6f8f7]">
      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-[#edf6f3] text-[#126e5e]">
        <Icon name={icon} className="size-5" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="mb-0.5 text-[11px] font-bold uppercase tracking-[0.08em] text-[#89938f]">{label}</div>
        {children ?? <div className="truncate text-sm font-bold text-[#18322c]">{value}</div>}
      </div>
    </div>
  );
}

export default function App() {
  const [tripType, setTripType] = useState<"one-way" | "round-trip">("one-way");
  const [from, setFrom] = useState("New York");
  const [to, setTo] = useState("Boston");
  const [searched, setSearched] = useState(false);

  const swapRoute = () => {
    setFrom(to);
    setTo(from);
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#fbfcfa] text-[#18322c]">
      <header className="relative z-20 border-b border-[#dfe6e3] bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-20 max-w-[1200px] items-center justify-between px-5 lg:px-8">
          <a href="#" className="flex items-center gap-2.5" aria-label="Routey home">
            <span className="flex size-10 items-center justify-center rounded-xl bg-[#136f60] text-white shadow-[0_6px_16px_rgba(19,111,96,.2)]">
              <Icon name="bus" className="size-6" />
            </span>
            <span className="text-xl font-extrabold tracking-[-0.04em]">routey</span>
          </a>
          <nav className="hidden items-center gap-8 text-sm font-semibold md:flex">
            <a className="text-[#136f60]" href="#search">Book a trip</a>
            <a className="text-[#63706c] transition hover:text-[#18322c]" href="#routes">Popular routes</a>
            <a className="text-[#63706c] transition hover:text-[#18322c]" href="#how">How it works</a>
          </nav>
          <div className="hidden items-center gap-3 md:flex">
            <button className="rounded-xl px-4 py-2.5 text-sm font-bold text-[#3e504b] transition hover:bg-[#f1f5f3]">Sign in</button>
            <button className="rounded-xl bg-[#18322c] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-[#25473f]">Create account</button>
          </div>
          <button className="flex size-10 items-center justify-center rounded-xl border border-[#dfe6e3] md:hidden" aria-label="Open menu">
            <Icon name="menu" />
          </button>
        </div>
      </header>

      <section className="relative">
        <div className="absolute inset-x-0 top-0 h-[520px] bg-[#eaf5f1]" />
        <div className="absolute right-[-8%] top-0 h-[520px] w-[51%] overflow-hidden rounded-bl-[100px] max-lg:hidden">
          <img
            className="h-full w-full object-cover"
            src="https://images.unsplash.com/photo-1570125909232-eb263c188f7e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=85&w=1400"
            alt="Modern intercity coach ready for a trip"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#eaf5f1] via-[#eaf5f1]/15 to-transparent" />
        </div>

        <div className="relative mx-auto max-w-[1200px] px-5 pb-14 pt-16 lg:px-8 lg:pb-20 lg:pt-20">
          <div className="max-w-2xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#bedbd3] bg-white/70 px-3.5 py-2 text-xs font-bold text-[#136f60]">
              <span className="size-2 rounded-full bg-[#e97840]" />
              Over 2,500 destinations nationwide
            </div>
            <h1 className="max-w-[620px] text-5xl font-extrabold leading-[1.04] tracking-[-0.055em] text-[#153c34] sm:text-6xl">
              Your next journey, <span className="text-[#e46f39]">made simple.</span>
            </h1>
            <p className="mt-5 max-w-lg text-base leading-7 text-[#556a64] sm:text-lg">
              Compare routes, choose your seat, and travel comfortably. Booking the bus has never felt this easy.
            </p>
          </div>

          <div id="search" className="relative mt-10 max-w-[1080px] rounded-[28px] bg-white p-2 shadow-[0_24px_60px_rgba(23,67,57,.16)]">
            <div className="flex gap-1 p-2">
              {(["one-way", "round-trip"] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setTripType(type)}
                  className={`rounded-xl px-4 py-2 text-xs font-extrabold capitalize transition ${tripType === type ? "bg-[#18322c] text-white" : "text-[#75817d] hover:bg-[#f1f5f3]"}`}
                >
                  {type.replace("-", " ")}
                </button>
              ))}
            </div>
            <div className="grid items-center gap-1 border-t border-[#edf0ef] p-2 lg:grid-cols-[1fr_auto_1fr_1fr_.75fr_auto]">
              <Field icon="location" label="From">
                <input value={from} onChange={(event) => setFrom(event.target.value)} className="w-full bg-transparent text-sm font-bold text-[#18322c] outline-none" aria-label="Departure city" />
              </Field>
              <button onClick={swapRoute} className="mx-auto flex size-10 items-center justify-center rounded-full border border-[#dfe6e3] bg-white text-[#136f60] transition hover:rotate-180 hover:bg-[#eaf5f1]" aria-label="Swap departure and destination">
                <Icon name="swap" className="size-4" />
              </button>
              <Field icon="location" label="To">
                <input value={to} onChange={(event) => setTo(event.target.value)} className="w-full bg-transparent text-sm font-bold text-[#18322c] outline-none" aria-label="Destination city" />
              </Field>
              <Field icon="calendar" label="Depart" value="Fri, 24 May" />
              <Field icon="users" label="Travelers" value="1 Adult" />
              <button onClick={() => setSearched(true)} className="m-1 flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-[#e56e37] px-7 text-sm font-extrabold text-white shadow-[0_10px_22px_rgba(229,110,55,.25)] transition hover:-translate-y-0.5 hover:bg-[#d95f2b]">
                <Icon name="search" className="size-5" />
                Search
              </button>
            </div>
          </div>

          {searched && (
            <div className="mt-4 flex max-w-[1080px] items-center justify-between rounded-2xl border border-[#bedbd3] bg-white px-5 py-4 shadow-sm">
              <div className="flex items-center gap-3 text-sm">
                <span className="flex size-9 items-center justify-center rounded-full bg-[#eaf5f1] text-[#136f60]"><Icon name="check" className="size-5" /></span>
                <span><strong>12 trips found</strong> from {from} to {to}</span>
              </div>
              <button onClick={() => setSearched(false)} className="text-xs font-bold text-[#667570] hover:text-[#18322c]">Dismiss</button>
            </div>
          )}

          <div className="mt-7 flex flex-wrap gap-x-8 gap-y-3 text-sm font-semibold text-[#52635e]">
            {["No booking fees", "Instant confirmation", "Free cancellation on select trips"].map((item) => (
              <span key={item} className="flex items-center gap-2">
                <span className="flex size-5 items-center justify-center rounded-full bg-[#cfe7df] text-[#136f60]"><Icon name="check" className="size-3.5" /></span>
                {item}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section id="routes" className="mx-auto max-w-[1200px] px-5 py-20 lg:px-8">
        <div className="mb-9 flex items-end justify-between gap-5">
          <div>
            <p className="mb-2 text-xs font-extrabold uppercase tracking-[0.14em] text-[#e46f39]">Trending now</p>
            <h2 className="text-3xl font-extrabold tracking-[-0.04em] sm:text-4xl">Popular routes</h2>
          </div>
          <button className="hidden items-center gap-2 text-sm font-bold text-[#136f60] sm:flex">View all routes <Icon name="arrow" className="size-4" /></button>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          {routes.map((route, index) => (
            <article key={route.from} className="group overflow-hidden rounded-[24px] border border-[#dfe6e3] bg-white p-2 transition hover:-translate-y-1 hover:shadow-[0_20px_45px_rgba(24,50,44,.1)]">
              <div className={`${route.color} relative flex h-36 items-center justify-center overflow-hidden rounded-[18px]`}>
                <span className="absolute left-5 top-4 text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#6b7773]">Route 0{index + 1}</span>
                <div className={`flex size-16 items-center justify-center rounded-full bg-white/80 ${route.accent} shadow-sm`}>
                  <Icon name="bus" className="size-8" />
                </div>
                <div className="absolute inset-x-5 bottom-5 border-t border-dashed border-[#9caaa5]/50" />
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-extrabold tracking-[-0.02em]">{route.from} <span className="px-1 text-[#9aa6a2]">→</span> {route.to}</h3>
                    <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-[#71807b]"><Icon name="clock" className="size-4" /> {route.duration} · Direct</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase text-[#95a09c]">From</p>
                    <p className="text-xl font-extrabold text-[#136f60]">${route.price}</p>
                  </div>
                </div>
                <button onClick={() => { setFrom(route.from); setTo(route.to); setSearched(true); window.scrollTo({ top: 260, behavior: "smooth" }); }} className="mt-5 flex w-full items-center justify-between rounded-xl border border-[#dfe6e3] px-4 py-3 text-sm font-bold transition group-hover:border-[#136f60] group-hover:bg-[#136f60] group-hover:text-white">
                  Explore trips <Icon name="chevron" className="size-4" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="how" className="bg-[#153c34] text-white">
        <div className="mx-auto max-w-[1200px] px-5 py-20 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
            <div>
              <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.14em] text-[#f39a70]">Simple by design</p>
              <h2 className="text-3xl font-extrabold leading-tight tracking-[-0.04em] sm:text-4xl">From search to seat in just a few clicks.</h2>
              <p className="mt-5 max-w-md leading-7 text-[#b9d0ca]">We bring trusted bus operators together, so your perfect trip is always easy to find and book.</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                { icon: "search" as IconName, number: "01", title: "Search", body: "Tell us where and when you want to go." },
                { icon: "ticket" as IconName, number: "02", title: "Choose", body: "Compare times, amenities, and prices." },
                { icon: "bus" as IconName, number: "03", title: "Travel", body: "Show your e-ticket and enjoy the ride." },
              ].map((step) => (
                <div key={step.title} className="rounded-[20px] border border-white/10 bg-white/[.06] p-5">
                  <div className="mb-8 flex items-center justify-between">
                    <span className="flex size-11 items-center justify-center rounded-xl bg-[#e56e37]"><Icon name={step.icon} /></span>
                    <span className="text-xs font-extrabold text-[#86aaa1]">{step.number}</span>
                  </div>
                  <h3 className="font-extrabold">{step.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-[#b9d0ca]">{step.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1200px] gap-6 px-5 py-12 sm:grid-cols-3 lg:px-8">
        {[
          { icon: "shield" as IconName, title: "Secure payments", text: "Your data is always protected" },
          { icon: "headset" as IconName, title: "Human support", text: "Real help, whenever you need it" },
          { icon: "wifi" as IconName, title: "Travel comfortably", text: "Find Wi-Fi and premium amenities" },
        ].map((feature) => (
          <div key={feature.title} className="flex items-center gap-4 rounded-2xl border border-[#e2e8e5] bg-white p-5">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-[#edf6f3] text-[#136f60]"><Icon name={feature.icon} /></span>
            <div><h3 className="text-sm font-extrabold">{feature.title}</h3><p className="mt-1 text-xs text-[#72807c]">{feature.text}</p></div>
          </div>
        ))}
      </section>

      <footer className="border-t border-[#dfe6e3] bg-white">
        <div className="mx-auto flex max-w-[1200px] flex-col items-center justify-between gap-4 px-5 py-7 text-xs text-[#78837f] sm:flex-row lg:px-8">
          <div className="flex items-center gap-2 font-extrabold text-[#18322c]"><Icon name="bus" className="size-5 text-[#136f60]" /> routey</div>
          <p>© 2025 Routey. Journeys that feel good.</p>
          <div className="flex gap-5"><a href="#">Help</a><a href="#">Terms</a><a href="#">Privacy</a></div>
        </div>
      </footer>
    </main>
  );
}
